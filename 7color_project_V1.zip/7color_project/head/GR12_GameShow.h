#ifndef GAME_SHOW_H
#define GAME_SHOW_H
#include "../head/GameState.h"
#include "../head/GR12_GameCore.h"
#include <stdlib.h>
#include <stdio.h>

// Forward declaration
typedef struct GameState GameState;
typedef enum Color Color;

void GR12_show_map(GameState* map);
void GR12_end_game(Color winner);
#endif