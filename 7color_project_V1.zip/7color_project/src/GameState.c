#include "../head/GameState.h"

GameState state = {.map = NULL, .size = 0};

void create_empty_game_state (GameState* state, int size){
	state -> size = size;
	state -> map = (Color*)malloc(size*size*sizeof(Color));
}

void set_map_value (GameState* state, int x, int y, Color value){
	state -> map[y * state -> size + x] = value;
}

Color get_map_value (GameState* state, int x, int y){
	if (state -> map == NULL || x > state -> size || y > state -> size || x < 0 || y < 0)
	{
		printf("[ERROR] map not big enough or not initialized %p %i access (%i %i)", state -> map, state -> size, x, y);
		return ERROR;
	}
	return state -> map[y * state -> size + x];
}

void fill_map (GameState* map){
	// On initialise la graine de l'aléatoire avec le temps actuel.
	srand(time(NULL)); 
	// On parcourt l'entièreté de la map
	for (int i=0; i<=(map->size*map->size); i++){
		// On rempli la carte aléatoirement avec les colors.
		Color Colors[] = {RED,GREEN,BLUE,YELLOW,MAGENTA,CYAN,WHITE};
		map->map[i] = Colors[rand() %6];
	}
	// On place les joueurs
	map->map[(map->size-1)*map->size] = PLAYER_1;
	map->map[(map->size-1)] = PLAYER_2;
}

int main (int argc, char** argv){
	//  ## Initialisation du jeu ################
	// On récupère la taille
	int size = atoi(argv[1]);
	// On génère la carte.
	create_empty_game_state(&state, size);
	// On remplit la carte.
	fill_map(&state);
	//  ## Fin Initialisation du jeu ############

	// ## Choix des joueurs #####################
	int GR12_player1;
	int GR12_player2;
	printf("Choix du premier joueur (premier à jouer) :\n");
	printf("[1] : Humain, [2] : IA aléatoire \n\n-> ");
	scanf("%d", &GR12_player1);

	printf("Choix du second joueur :\n");
	printf("[1] : Humain, [2] : IA aléatoire \n\n-> ");
	scanf("%d", &GR12_player2);
	// ## Fin choix des joueurs #################

	while (GR12_win_game(&state)){
		
	}

	GR12_show_map(&state);
	
	GR12_win_game(&state);

	if (GR12_win_game(&state)){return 0;}

	return 1;
}