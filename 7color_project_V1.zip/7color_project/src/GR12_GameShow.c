#include "../head/GR12_GameShow.h"

extern char* strcolors[];

void GR12_show_map (GameState* map){
    for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            Color value = get_map_value(map, i, j);
            printf("%d ",value);
        }
        printf("\n");
	}
}

void GR12_end_game(Color winner){
  printf("Le joueur %s a gagné", strcolors[winner]);
}