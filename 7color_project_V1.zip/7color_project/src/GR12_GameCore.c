#include "../head/GR12_GameCore.h"

const char* strcolors[] = {"EMPTY", "PLAYER_1", "PLAYER_2", "RED", "GREEN", "BLUE", "YELLOW", "MAGENTA", "CYAN", "WHITE"};

void GR12_update_map (GameState* map, Color player, Color move){
    int updates = 0;
    for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            if (get_map_value(map, i, j) == move){
                // On check les adjacents
                if (get_map_value(map, i-1, j) == player){set_map_value(map, i, j, move); updates++;}
                if (get_map_value(map, i+1, j) == player){set_map_value(map, i, j, move); updates++;}
                if (get_map_value(map, i, j-1) == player){set_map_value(map, i, j, move); updates++;}
                if (get_map_value(map, i, j+1) == player){set_map_value(map, i, j, move); updates++;}
            }
        }
	}
    // Si on a fait des modifications, il faut reparcourir la map.
    if (updates){GR12_update_map(map, player, move);}
}

int GR12_win_game (GameState* map){
    // On initialise les compteurs
    int count_P1 = 0, count_P2 = 0;

    // On parcourt toute la map pour savoir l'étendue des territoires de chaque joueur.
    for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            if (get_map_value(map, i, j) == PLAYER_1){count_P1++;}
            if (get_map_value(map, i, j) == PLAYER_2){count_P2++;}
        }
	}

    // Détermination de l'état de la partie
    // Victoire d'un des deux joueurs (territoire>50% de la map)
    if (count_P1 > 0.5*map->size*map->size){GR12_end_game(PLAYER_1); return 1;}
    
    if (count_P2 > 0.5*map->size*map->size){GR12_end_game(PLAYER_2); return 1;}
    // Cas d'égalité (50/50)
    if (count_P1 == count_P2 == 0.5*map->size*map->size){GR12_end_game(EMPTY); return 1;} 
    // La partie n'est pas finie (Personne n'a la majorité et des coups peuvent encore être joué)
    return 0;
}