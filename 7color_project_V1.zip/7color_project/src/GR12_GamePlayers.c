#include "../head/GR12_GamePlayers.h"

Color GR12_player_human(GameState* state, Color player){
    Color move;
    
    printf("Veuillez choisir une couleur : ");
    scanf("%c", &move);

    return move;
}

Color GR12_player_AI_random(GameState* map, Color player){
    return EMPTY
}