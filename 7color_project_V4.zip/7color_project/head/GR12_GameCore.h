#ifndef GAME_CORE_H
#define GAME_CORE_H
#include "../head/GameState.h"
#include "../head/GR12_GameShow.h"
#include <stdlib.h>
#include <stdio.h>

// Forward declaration
typedef struct GameState GameState;
typedef enum Color Color;

void GR12_update_map (GameState* map, Color player, Color move);
void GR12_playable_colors(GameState* map, Color player, int* playable_colors);
int GR12_player_ratio(GameState* map, Color player);
int GR12_win_game(GameState* map);
#endif