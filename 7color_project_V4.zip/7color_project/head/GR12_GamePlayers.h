#ifndef GAME_PLAYERS_H
#define GAME_PLAYERS_H
#include "../head/GameState.h"
#include "../head/GR12_GameShow.h"
#include <stdlib.h>
#include <stdio.h>

// Forward declaration
typedef struct GameState GameState;
typedef enum Color Color;

// Variables externes à importer


// Fonctions du fichier
Color GR12_player_human(GameState* state, Color player);
Color GR12_player_AI_random(GameState* map, Color player);
#endif