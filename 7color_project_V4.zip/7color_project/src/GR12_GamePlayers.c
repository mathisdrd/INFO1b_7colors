#include "../head/GR12_GamePlayers.h"

extern const Color colors[7];

// On définit les différents types de joueurs disponibles
Color (*players[2])(GameState*, Color) = {GR12_player_human, GR12_player_AI_random};

Color GR12_player_human(GameState* state, Color player){
    Color color;
    int move;
    int verif; // Pour vérifier que le scanf réussis
    
    /* VERSION AFFICHE CLASSIQUE
    printf("Veuillez choisir une couleur à jouer : \033[30m(Valeur entre 3 et 9)\033[0m\n");
    printf("[3]\t[4]\t[5]\t[6]\t[7]\t[8]\t[9]\n\n-> ");

    do{ // Script de vérification du scanf
        verif = scanf("%d", &move);
        if (1 != verif || move < 3 || move > 9){
            printf("\n[\033[31mERROR\033[0m] La valeur entrée n'est pas un entier ou n'est pas comprise entre 3 et 9.\n        Veuillez réessayer :\n\n-> ");
            // On vide le buffer d'entrée
            while (getchar() != '\n');
        }
    } while (1 != verif || move < 3 || move > 9);
    printf("\n");

    move -= 3; // Il y a PLAYER_1 et PLAYER_2 et l'indicage commence à 0.
    //*/// FIN VERSION AFFICHAGE CLASSIQUE

    //* VERSION AFFICHAGE FANCY
    printf("Veuillez choisir une couleur à jouer : \033[30m(Lettre correspondante)\033[0m\n");
    printf("[R] Rouge | [V] Vert | [B] Bleu | [J] Jaune | [M] Magenta | [C] Cyan | [O] Orange\n\n-> ");
    char strmove;
    do{ // Script de vérification du scanf
        verif = scanf(" %c", &strmove);
        if (1 != verif || !(strmove == 'R' || strmove == 'V' || strmove == 'B' || strmove == 'J' || strmove == 'M' || strmove == 'C' || strmove == 'O')){
            printf("\n[\033[31mERROR\033[0m] La valeur entrée n'est pas un caractère valide (R, V, B, J, M, C, O).\n        Veuillez réessayer :\n\n-> ");
            // On vide le buffer d'entrée
            while (getchar() != '\n');
        }
    } while (1 != verif || !(strmove == 'R' || strmove == 'V' || strmove == 'B' || strmove == 'J' || strmove == 'M' || strmove == 'C' || strmove == 'O'));
    printf("\n");

    // On associe la valeur entière en fonction de la couleur
    switch(strmove){
        case 'R': move = 0; break;
        case 'V': move = 1; break;
        case 'B': move = 2; break;
        case 'J': move = 3; break;
        case 'M': move = 4; break;
        case 'C': move = 5; break;
        case 'O': move = 6; break;
    }
    //*/// FIN VERSION AFFICHAGE FANCY

    // On récupère la couleur associée au choix de l'utilisateur
    color = colors[move];
    return color;
}

Color GR12_player_AI_random(GameState* map, Color player){
    return EMPTY;
}