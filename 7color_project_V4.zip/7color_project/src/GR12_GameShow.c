#include "../head/GR12_GameShow.h"

const char* strcolors[] = {"EMPTY", "PLAYER_1", "PLAYER_2", "RED", "GREEN", "BLUE", "YELLOW", "MAGENTA", "CYAN", "WHITE"}; // A retirer si on s'en sert pas à la fin
extern Color (*players[2])(GameState*, Color);

void GR12_show_map(GameState* map){
  	for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            Color value = get_map_value(map, i, j);
            printf("%d ",value);
        }
        printf("\n");
	}
}

void GR12_fancy_show_map(GameState* map){
	// Affichage de l'avancée :
	int nb_pixel_P1 = GR12_player_ratio(map, PLAYER_1) * (2*map->size)/100;
	int nb_pixel_P2 = GR12_player_ratio(map, PLAYER_2) * (2*map->size)/100;

	printf("⟡"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⩤⩥"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⟡\n");
	printf("|");
	for(int i=0; i<nb_pixel_P2; i++){printf("\033[48;5;0m \033[0m");}
	for(int i=0; i<((2*map->size) - nb_pixel_P1 - nb_pixel_P2); i++){printf(" ");}
	for(int i=0; i<nb_pixel_P1; i++){printf("\033[47m \033[0m");}
	printf("|\n");
	printf("⟡"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⩤⩥"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⟡\n");
	// Fin affichage de l'avancée

	// Affichage de la map
	printf("⟡"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⩤⩥"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⟡\n");
	for (int i=0; i<(map->size); i++){
		if (map->size % 2){if (i == map->size/2){printf("⟠");}else {printf("|");}}
		else {if (i == map->size/2-1){printf("∆");} else if (i == map->size/2){printf("∇");} else {printf("|");}}
		for (int j=0; j<(map->size); j++){
			Color value = get_map_value(map, i, j);
			switch(value){
				case PLAYER_1 : printf("\033[47m  \033[0m");       break;
				case PLAYER_2 : printf("\033[48;5;0m  \033[0m");   break;
				case RED :      printf("\033[41m  \033[0m");       break;
				case GREEN :    printf("\033[42m  \033[0m");       break;
				case BLUE :     printf("\033[44m  \033[0m");       break;
				case YELLOW :   printf("\033[43m  \033[0m");       break;
				case MAGENTA :  printf("\033[45m  \033[0m");       break;
				case CYAN :     printf("\033[106m  \033[0m");      break;
				case WHITE :    printf("\033[48;5;208m  \033[0m"); break;
				default : break;
			}
		}
		if (map->size % 2){if (i == map->size/2){printf("⟠\n");}else {printf("|\n");}}
		else {if (i == map->size/2-1){printf("∆\n");} else if (i == map->size/2){printf("∇\n");} else {printf("|\n");}}
	}
	printf("⟡"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⩤⩥"); for(int i=0; i<(map->size)-1; i++){printf("∼");} printf("⟡\n");
}

void GR12_ASCII_title(){
	printf(" _____         _\n|___  |__ ___ | | ___  _ __ ___\n   / / __/ _ \\| |/ _ \\| '__/ __|\n  / / (_| (_) | | (_) | |  \\__ \\\n /_/ \\___\\___/|_|\\___/|_|  |___/\n\n");
}

void GR12_begin_game(GameState* map, int player1, int player2){
	char* strplayer1;
  	char* strplayer2;
  	switch(player1){
    	case 0 :
      		strplayer1 = " _    _                             \n| |  | |                            \n| |__| |_   _ _ __ ___   __ _ _ __  \n|  __  | | | | '_ ` _ \\ / _` | '_ \\ \n| |  | | |_| | | | | | | (_| | | | |\n|_|  |_|\\__,_|_| |_| |_|\\__,_|_| |_|\n";
      		break;
    	case 1 :
      		strplayer1 = " _____                 _                 \n|  __ \\               | |                \n| |__) |__ _ _ __   __| | ___  _ __ ___  \n|  _  // _` | '_ \\ / _` |/ _ \\| '_ ` _ \\ \n| | \\ \\ (_| | | | | (_| | (_) | | | | | |\n|_|  \\_\\__,_|_| |_|\\__,_|\\___/|_| |_| |_|\n";
    		break;
  	}

  	switch(player2){
    	case 0 :
      		strplayer2 = "\t\t _    _                             \n\t\t| |  | |                            \n\t\t| |__| |_   _ _ __ ___   __ _ _ __  \n\t\t|  __  | | | | '_ ` _ \\ / _` | '_ \\ \n\t\t| |  | | |_| | | | | | | (_| | | | |\n\t\t|_|  |_|\\__,_|_| |_| |_|\\__,_|_| |_|\n";
      		break;
    	case 1 :
      		strplayer2 = "\t\t _____                 _                 \n\t\t|  __ \\               | |                \n\t\t| |__) |__ _ _ __   __| | ___  _ __ ___  \n\t\t|  _  // _` | '_ \\ / _` |/ _ \\| '_ ` _ \\ \n\t\t| | \\ \\ (_| | | | | (_| | (_) | | | | | |\n\t\t|_|  \\_\\__,_|_| |_|\\__,_|\\___/|_| |_| |_|\n";
    		break;
  	}
  	
  	printf("%s\t__      ____  \n\t\\ \\    / / /  \n\t \\ \\  / / /__ \n\t  \\ \\/ / / __|\n\t   \\  / /\\__ \\\n\t    \\/_/ |___/\n%s\n", strplayer1, strplayer2);

  	printf("Voici l'état initial : \n\n");
	GR12_fancy_show_map(map);
}

void GR12_end_game(Color winner){
	switch(winner){
		case PLAYER_1 : printf("Le joueur 1 a gagné !\n\n"); break;
		case PLAYER_2 : printf("Le joueur 2 a gagné !\n\n"); break;
		case EMPTY : printf("Égalité stricte ! Aucun gagnant !\n\n"); break;
		default : printf("[\033[31mERROR\033[0m] Quelque chose d'inattendu s'est produit T-T\n\n"); break;
	}
}