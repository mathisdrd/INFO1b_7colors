#include "../head/GameState.h"

GameState state = {.map = NULL, .size = 0};
const Color colors[7] = {RED,GREEN,BLUE,YELLOW,MAGENTA,CYAN,WHITE};
extern Color (*players[2])(GameState*, Color);

void create_empty_game_state (GameState* state, int size){
	state -> size = size;
	state -> map = (Color*)malloc(size*size*sizeof(Color));
}

void set_map_value (GameState* state, int x, int y, Color value){
	state -> map[y * state -> size + x] = value;
}

Color get_map_value (GameState* state, int x, int y){
	// Il y avait une erreur ici, il faut mettre x>= et non x>, de même pour y.
	if (state -> map == NULL || x >= state -> size || y >= state -> size || x < 0 || y < 0){
		printf("[ERROR] map not big enough or not initialized %p %i access (%i %i)\n", state -> map, state -> size, x, y);
		return ERROR;
	}
	return state -> map[y * state -> size + x];
}

void fill_map (GameState* map){
	// On initialise la graine de l'aléatoire avec le temps actuel.
	srand(time(NULL)); 
	// On parcourt l'entièreté de la map
	for (int i=0; i<(map->size*map->size); i++){
		// On rempli la carte aléatoirement avec les colors.
		map->map[i] = colors[rand() %7];
	}
	// On place les joueurs
	map->map[(map->size-1)*map->size] = PLAYER_1;
	map->map[(map->size-1)] = PLAYER_2;
}

int main (int argc, char** argv){
	// Titre du jeu
	GR12_ASCII_title();

	//  ## Initialisation du jeu ################
	// Vérification que l'argument de taille a bien été donné :
	int size;

	if (argc == 1){ // L'argument n'existe pas
		printf("[\033[31mERROR\033[0m] Aucun argument donné, entrez une taille de plateau\n\n-> ");
		scanf("%d", &size);
		printf("\n");
	} else { // L'argument existe
		size = atoi(argv[1]);

		if (argc > 2){ // Trop d'arguments ont été donnés
		printf("[\033[33mWARNING\033[0m] Trop d'arguments ont été donnés\n");
		}
	}

	// On vérifie que la taille est supérieure à 1
	while(size<2 || size > 300){
		printf("[\033[31mERROR\033[0m] La taille choisit doit être comprise entre 2 et 300.\n        Veuillez entrer une taille valable :\n\n-> ");
		scanf("%d", &size);
		printf("\n");
	}

	// On génère la carte.
	create_empty_game_state(&state, size);
	// On remplit la carte.
	fill_map(&state);
	//  ## Fin Initialisation du jeu ############

	// ## Choix des joueurs #####################
	// On définir les indices des choix de joueurs
	int player1, player2;

	// On demande à l'utilisateur de choisir les types de joueurs
	printf("Choix du premier joueur (premier à jouer) :\n"); // Couleur PLAYER_1
	printf("[1] : Humain, [2] : IA aléatoire \n\n-> ");
	scanf("%d", &player1);
	player1 -= 1; // L'indicage des listes commence à 0

	printf("\nChoix du second joueur :\n"); // Couleur PLAYER_2
	printf("[1] : Humain, [2] : IA aléatoire \n\n-> ");
	scanf("%d", &player2);
	player2 -= 1;
	printf("\n");

	// ## Fin choix des joueurs #################
	
	GR12_begin_game(&state, player1, player2);

	// ## Corps du jeu ##########################
	int turn_to = 0;
	Color color;
	while (!GR12_win_game(&state)){
		switch(turn_to){
			case 0:
				printf("\n\033[47m  \033[0m Au joueur 1 de jouer :\n\n");
				// Le joueur choisit un couleur à jouer
				color = players[player1](&state, PLAYER_1);
				// On update la map selon le coup choisit
				GR12_update_map(&state, PLAYER_1, color);
				break; // Pour quitter le switch
			case 1: 
				printf("\n\033[48;5;0m  \033[0m Au joueur 2 de jouer :\n\n");
				color = players[player2](&state, PLAYER_2);
				GR12_update_map(&state, PLAYER_2, color);
				break;
		}
		GR12_fancy_show_map(&state); // Si on remplace GR12_fancy_show_map par GR12_show_map, il faut également modifier les blocs fancy dans le joueur humain
		printf("\n");
		// On passe au tour du prochain joueur
		turn_to = (turn_to + 1) % 2; // On pourrait aussi écrire : turn_to ^= 1;
	}
	// ## Fin corps du jeu ######################

	// Free des variables allouées avec malloc()
	free(state.map);
	state.map = NULL;
	return 1;
}