#include "../head/GR12_GameCore.h"

extern const Color colors[7];

void GR12_update_map (GameState* map, Color player, Color move){
    int updates = 0;
    for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            if (get_map_value(map, i, j) == player){
                // On check les adjacents avec une vérification paresseuse pour ne pas dépasser la map.
                if (i != 0           && get_map_value(map, i-1, j) == move) {set_map_value(map, i-1, j, player); updates++;}
                if (i != map->size-1 && get_map_value(map, i+1, j) == move) {set_map_value(map, i+1, j, player); updates++;}
                if (j != 0           && get_map_value(map, i, j-1) == move) {set_map_value(map, i, j-1, player); updates++;}
                if (j != map->size-1 && get_map_value(map, i, j+1) == move) {set_map_value(map, i, j+1, player); updates++;}
            }
        }
	}
    
    // Si on a fait des modifications, il faut reparcourir la map.
    if(updates){GR12_update_map(map, player, move);}
}

void GR12_playable_colors(GameState* map, Color player, int* playable_colors){
    // On initialise le tableau à modifier
    for (int i=0; i<7; i++){playable_colors[i] = 0;}
    
    for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            if (get_map_value(map, i, j) == player){
                // On check les adjacents avec une vérification paresseuse pour ne pas dépasser la map.
                if (i != 0           && (get_map_value(map, i-1, j) != PLAYER_1 || get_map_value(map, i-1, j) != PLAYER_2)) {playable_colors[get_map_value(map, i-1, j) - 3] = 1;}
                if (i != map->size-1 && (get_map_value(map, i+1, j) != PLAYER_2 || get_map_value(map, i+1, j) != PLAYER_2)) {playable_colors[get_map_value(map, i+1, j) - 3] = 1;}
                if (j != 0           && (get_map_value(map, i, j-1) != PLAYER_2 || get_map_value(map, i, j-1) != PLAYER_2)) {playable_colors[get_map_value(map, i, j-1) - 3] = 1;}
                if (j != map->size-1 && (get_map_value(map, i, j+1) != PLAYER_2 || get_map_value(map, i, j+1) != PLAYER_2)) {playable_colors[get_map_value(map, i, j+1) - 3] = 1;}
            }
        }
	}
}

int GR12_player_ratio(GameState* map, Color player){
    int count = 0;

    // On parcourt toute la map pour savoir l'étendue du territoires du joueur.
    for (int i=0; i<(map->size); i++){
		for (int j=0; j<(map->size); j++){
            if (get_map_value(map, i, j) == player){count++;}
        }
	}

    return 100 * count / (map->size*map->size);
}

int GR12_win_game (GameState* map){
    // On récupère la partie du territoire conquis par chaque utilisateur
    int count_P1 = GR12_player_ratio(map, PLAYER_1);
    int count_P2 = GR12_player_ratio(map, PLAYER_2);

    // On récuère le nombre de couleurs jouable pour savoir si le joueur peut encore jouer
    int playable_P1[7]; GR12_playable_colors(map, PLAYER_1, playable_P1);
    int playable_P2[7]; GR12_playable_colors(map, PLAYER_2, playable_P2);
    
    int nb_colors_P1 = 0;
    int nb_colors_P2 = 0;

    for (int i=0; i<7; i++){
        nb_colors_P1 += playable_P1[i];
        nb_colors_P2 += playable_P2[i];
    }

    // Détermination de l'état de la partie : 1 = partie finie, 0 = partie pas encore finie
    // Si l'un des joueurs à +50% de la map, victoire
    if (count_P1 > 50){GR12_end_game(PLAYER_1); return 1;}
    if (count_P2 > 50){GR12_end_game(PLAYER_2); return 1;}

    // Si les deux joueurs ont 50% de la map, égalité
    if (count_P1 == count_P2 && count_P1 == 50){GR12_end_game(EMPTY); return 1;}

    // Si un joueur est en dessous de 50% et ne peut plus jouer de coup, il a forcément perdu
    if (nb_colors_P2 == 0){GR12_end_game(PLAYER_1); return 1;}
    if (nb_colors_P1 == 0){GR12_end_game(PLAYER_2); return 1;}

    // La partie n'est pas finie (Personne n'a la majorité et des coups peuvent encore être joué)
    return 0;
}